
package com.example.kozmiksword;

import net.fabricmc.api.ModInitializer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class KozmikSwordMod implements ModInitializer {
    public static final Item KOZMIK_SWORD = new SwordItem(
        ToolMaterials.DIAMOND, 26, -2.4F, new Item.Settings().fireproof().maxCount(1).group(ItemGroup.COMBAT)
    );

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier("kozmiksword", "kozmik_sword"), KOZMIK_SWORD);
    }
}
